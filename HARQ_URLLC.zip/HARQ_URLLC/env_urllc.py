import gymnasium as gym
import numpy as np

class ENV_paper:
    def __init__(self, lambda_rate, D_max, xi, max_power, snr_feedback, harq_type):
        # System parameters
        self.lambda_rate = lambda_rate  # Average arrival rate (bits/slot)
        self.D_max = D_max  # Maximum delay (slots)
        self.xi = xi  # Target delay violation probability
        self.max_power = max_power  # Maximum power
        self.snr_feedback = snr_feedback  # Whether SNR feedback is available
        self.harq_type = harq_type  # HARQ type: 'CC' or 'IR'
        self.n = 200  # Channel uses per slot
        self.T = int(10 / xi)  # Number of slots per episode
        self.Delta = 20 * max_power  # Large penalty constant
        self.beta = 16  # Exponent for penalty function

        # State space
        state_dim = 4 if not snr_feedback else 5
        self.observation_space = gym.spaces.Box(low=0, high=np.inf, shape=(state_dim,), dtype=np.float32)

        # Action space: [R(t), p(t)]
        self.action_space = gym.spaces.Box(low=np.array([0.1, 0.5]), high=np.array([np.inf, max_power]), dtype=np.float32)

        # History buffers
        self.arrival_history = []
        self.previous_snrs = []

        # Initialize state
        self.reset()

    def reset(self):
        # Reset environment to initial state
        self.q_t = 0  # Queue length
        self.A_t = np.random.poisson(self.lambda_rate)  # Arriving bits
        self.d_t = 0  # Number of delay violations in episode
        self.k = 0  # Number of transmissions for current packet
        self.t = 0  # Current timestep
        self.gamma_k = 0 if self.snr_feedback else None  # Remaining SNR
        self.arrival_history = [self.A_t]
        self.previous_snrs = []
        state = [self.q_t, self.A_t, self.d_t, self.k]
        if self.snr_feedback:
            state.append(self.gamma_k)
        return np.array(state)

    def step(self, action):
        R_t, p_t = action  # Coding rate and transmission power
        self.t += 1

        R_t = max(R_t, 0.1)
        p_t = np.clip(p_t, 0.5, self.max_power)

        # Simulate Rayleigh fading channel
        h = np.random.normal(0, 1) + 1j * np.random.normal(0, 1)
        snr = p_t * (np.abs(h)**2)

        # Determine transmission success
        if self.k == 0:  # New transmission
            success = np.log2(1 + snr) >= R_t
        else:  # Retransmission
            if self.harq_type == 'CC':
                if self.snr_feedback:
                    accumulated_snr = sum(self.previous_snrs) + snr
                    success = np.log2(1 + accumulated_snr) >= R_t
                else:
                    accumulated_snr = sum(self.previous_snrs) + snr
                    success = np.log2(1 + accumulated_snr) >= R_t
            elif self.harq_type == 'IR':
                if self.snr_feedback:
                    total_rate = sum([np.log2(1 + s) for s in self.previous_snrs]) + np.log2(1 + snr)
                    success = total_rate >= R_t

        # Calculate service rate S(t)
        S_t = self.n * R_t if success else 0

        # Update queue length temporarily
        q_tmp = max(self.q_t + self.A_t - S_t, 0)

        # Calculate q_th(t) based on arrival history
        if len(self.arrival_history) >= self.D_max:
            q_th = sum(self.arrival_history[-self.D_max:])
        else:
            q_th = sum(self.arrival_history)

        # Check for delay violation
        if q_tmp > q_th:
            self.d_t += 1
            w_t = self._calculate_penalty()
            reward = -p_t - w_t
        else:
            reward = -p_t

        # Update queue with PODD
        self.q_t = min(q_tmp, q_th)

        # Update state
        self.A_t = np.random.poisson(self.lambda_rate)
        self.arrival_history.append(self.A_t)
        if len(self.arrival_history) > self.D_max:
            self.arrival_history.pop(0)

        if success:
            self.k = 0
            self.gamma_k = 0 if self.snr_feedback else None
            self.previous_snrs = []
        else:
            self.k += 1
            self.previous_snrs.append(snr)
            if self.snr_feedback:
                if self.harq_type == 'CC':
                    self.gamma_k = max(2**R_t - 1 - sum(self.previous_snrs), 0)
                elif self.harq_type == 'IR':
                    self.gamma_k = max((2**R_t) / np.prod([1 + s for s in self.previous_snrs]) - 1, 0)

        state = [self.q_t, self.A_t, self.d_t, self.k]
        if self.snr_feedback:
            state.append(self.gamma_k)

        # Check if episode is done
        done = self.t >= self.T

        info = {'power': p_t, 'delay_violation': self.d_t, 'Rate': R_t}

        return np.array(state), reward, done, info

    def _calculate_penalty(self):
        # Calculate penalty w(t) based on delay violations
        if self.d_t <= self.T * self.xi:
            return self.Delta * (self.d_t / (self.T * self.xi)) ** self.beta
        return self.Delta