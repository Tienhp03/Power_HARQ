"""
Hình 2: Vẽ công suất phát theo lưu lượng dữ liệu trung bình đến:
I. IR-HARQ feedback
\1. Lambda = 150
--- Average Results after 50 Episodes ---
Average total power: 506.18
Average power per episode: 0.51
Average total reward: -214260.30
Average delay violations: 573.64

\2. Lambda = 200
--- Average Results after 50 Episodes ---
Average total power: 1043.41
Average power per episode: 1.04
Average total reward: -310653.64
Average delay violations: 566.60
"""